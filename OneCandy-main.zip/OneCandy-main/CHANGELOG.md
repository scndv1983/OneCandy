# Change Log

## Releases:
- ### `0.0.1` - Initial release, basic color scheme and ReadMe examples
- ### `1.0.0` - Contained Github Repo info in the ReadMe and updated banner color to create the final base version
- ### `1.0.1` - Changed the banner color and tags
- ### `1.0.2` - Updated the description 😎 🤙
- ### `1.0.3` - Cleaned up the file structure, updated ReadMe and screenshots 🙃
- ### `1.0.4` - Removed ugly ReadMe break lines 🤠