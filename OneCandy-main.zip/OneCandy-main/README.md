# One Candy Dark 🍬
## Custom theme based around the One Dark Pro with pink accents and contrasting pastel colors.
<br />

## Lively composition lookin fresh while still keeping it mellow ✨
<br />

## `Typescript`
![Typescript Demo](https://i.imgur.com/ILVDW7Z.png)
<br />

## `Node`
![Node Demo](https://i.imgur.com/Uu2RHnm.png)
<br />
## `Scss`
![Scss Demo](https://i.imgur.com/5M2ILeu.png)


## Feel free to contribute to this project by adding a PR in the One Candy Dark [Repository](https://github.com/KacperBiedka/OneCandy) 